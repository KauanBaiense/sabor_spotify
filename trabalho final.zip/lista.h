#ifndef LISTA_H
#define LISTA_H

typedef struct nodo
{
    void *pObjeto;

    struct nodo *pProximo;
    struct nodo *pAnterior;

} NODO;

typedef struct lista LISTA;

struct lista
{
    char nome[50];

    NODO *pInicio;
    NODO *pFim;

    void (*insere)(LISTA *self, void *obj);
    void (*removeObjeto)(struct lista *self, void *obj);
    void (*paracada)(LISTA *self,void (*callback)(void *obj));
        
    void (*destroi)(LISTA *self);
};

LISTA *CriarLista(char *nome);


#endif