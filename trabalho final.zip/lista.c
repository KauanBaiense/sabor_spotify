#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lista.h"

//// Prototipos

void InsereLista(LISTA *self, void *obj);
void ParaCadaLista(LISTA *self,void (*callback)(void *obj));
void DestroiLista(LISTA *self);
void RemoveObjetoLista(LISTA *self,void *obj);

////////////////

LISTA *CriarLista(char *nome)
{
    LISTA *lista = malloc(sizeof(LISTA));

    strcpy(lista->nome, nome);

    lista->pInicio = NULL;
    lista->pFim = NULL;

    lista->insere = InsereLista;
    lista->paracada = ParaCadaLista;
    lista->destroi = DestroiLista;
    lista->removeObjeto = RemoveObjetoLista;

    return lista;
}

void InsereLista(LISTA *self, void *obj)
{
    NODO *novo = malloc(sizeof(NODO));

    novo->pObjeto = obj;
    novo->pProximo = NULL;
    novo->pAnterior = self->pFim;

    if(self->pFim)
        self->pFim->pProximo = novo;
    else
        self->pInicio = novo;

    self->pFim = novo;
}

void ParaCadaLista(
        LISTA *self,
        void (*callback)(void *obj))
{
    NODO *aux = self->pInicio;

    while(aux)
    {
        callback(aux->pObjeto);
        aux = aux->pProximo;
    }
}

void DestroiLista(LISTA *self)
{
    NODO *aux = self->pInicio;

    while(aux)
    {
        NODO *temp = aux;

        aux = aux->pProximo;

        free(temp);
    }

    free(self);

}

void RemoveObjetoLista(
        LISTA *self,
        void *obj)
{
    NODO *aux = self->pInicio;

    while(aux)
    {
        if(aux->pObjeto == obj)
        {
            if(aux->pAnterior)
                aux->pAnterior->pProximo =
                    aux->pProximo;
            else
                self->pInicio =
                    aux->pProximo;

            if(aux->pProximo)
                aux->pProximo->pAnterior =
                    aux->pAnterior;
            else
                self->pFim =
                    aux->pAnterior;

            free(aux);
            return;
        }

        aux = aux->pProximo;
    }
}