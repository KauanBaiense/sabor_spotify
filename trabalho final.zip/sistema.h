#ifndef SISTEMA_H
#define SISTEMA_H

#include "lista.h"

typedef struct
{
    LISTA *biblioteca;

    LISTA *playlists;

} SISTEMA;

SISTEMA *CriarSistema();


/* Biblioteca */
void SalvarBiblioteca(SISTEMA *sistema);
void CarregarBiblioteca(SISTEMA *sistema);

/* Playlists */
void SalvarPlaylists(SISTEMA *sistema);
void CarregarPlaylists(SISTEMA *sistema);

#endif