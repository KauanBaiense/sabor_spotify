#include "menu.h"
#include "sistema.h"

int main()
{
    SISTEMA *spotify = CriarSistema();

    CarregarBiblioteca(spotify);

    CarregarPlaylists(spotify);

    MenuPrincipal(spotify);

    SalvarBiblioteca(spotify);

    SalvarPlaylists(spotify);

    return 0;
}