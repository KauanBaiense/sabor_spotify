#include "playlist.h"

PLAYLIST *CriarPlaylist(char *nome)
{
    return CriarLista(nome);
}