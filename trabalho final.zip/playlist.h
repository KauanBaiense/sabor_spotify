#ifndef PLAYLIST_H
#define PLAYLIST_H

#include "lista.h"

typedef LISTA PLAYLIST;

PLAYLIST *CriarPlaylist(char *nome);

#endif