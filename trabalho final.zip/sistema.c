#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include "sistema.h"
#include "musica.h"
#include "playlist.h"

SISTEMA *CriarSistema()
{
    SISTEMA *sistema = malloc(sizeof(SISTEMA));

    sistema->biblioteca = CriarLista("Biblioteca");

    sistema->playlists = CriarLista("Playlists");

    return sistema;
}

////////////////////////////////////////

void SalvarBiblioteca(SISTEMA *sistema)
{
    FILE *file = fopen("biblioteca.dat", "w");

    if(!file)
        return;

    NODO *aux = sistema->biblioteca->pInicio;

    while(aux)
    {
        MUSICA *m = aux->pObjeto;

        fprintf(file,
            "%s,%s,%s,%s,%.2f\n",
            m->musica,
            m->genero,
            m->artista,
            m->link,
            m->minutos);

        aux = aux->pProximo;
    }

    fclose(file);
}

////////////////////////////////////////////////

void CarregarBiblioteca(SISTEMA *sistema)
{
    FILE *file = fopen("biblioteca.dat", "r");

    if(!file)
        {
        perror("Erro ao abrir biblioteca.dat");
        return;
        }

    char linha[512];

    while(fgets(linha,sizeof(linha),file))
    {
        MUSICA *m = malloc(sizeof(MUSICA));

        linha[strcspn(linha,"\n")] = '\0';

        sscanf(linha,
               "%99[^,],%49[^,],%49[^,],%99[^,],%f",
               m->musica,
               m->genero,
               m->artista,
               m->link,
               &m->minutos);

        sistema->biblioteca->insere(
            sistema->biblioteca,
            m);
    }

    fclose(file);
}

///////////////////////////////////////

void SalvarPlaylists(SISTEMA *sistema)
{
    FILE *file = fopen("playlists.dat","w");

    if(!file)
        return;

    NODO *auxPlaylist =
        sistema->playlists->pInicio;

    while(auxPlaylist)
    {
        PLAYLIST *playlist =
            auxPlaylist->pObjeto;

        int total = 0;

        NODO *auxMusica =
            playlist->pInicio;

        while(auxMusica)
        {
            total++;
            auxMusica = auxMusica->pProximo;
        }

        fprintf(file,
                "%s,%d\n",
                playlist->nome,
                total);

        auxMusica =
            playlist->pInicio;

        while(auxMusica)
        {
            MUSICA *m =
                auxMusica->pObjeto;

            fprintf(file,"%s\n",
                    m->musica);

            auxMusica =
                auxMusica->pProximo;
        }

        auxPlaylist =
            auxPlaylist->pProximo;
    }

    fclose(file);
}

///////////////////////////////////////////////

void CarregarPlaylists(SISTEMA *sistema)
{
    FILE *file = fopen("playlists.dat","r");

    if(!file)
        return;

    char linha[512];

    while(fgets(linha,sizeof(linha),file))
    {
        linha[strcspn(linha,"\n")] = '\0';

        char nomePlaylist[50];

        int total;

        sscanf(linha,
               "%49[^,],%d",
               nomePlaylist,
               &total);

        PLAYLIST *playlist =
            CriarPlaylist(nomePlaylist);

        sistema->playlists->insere(
            sistema->playlists,
            playlist);

        for(int i=0;i<total;i++)
        {
            fgets(linha,sizeof(linha),file);

            linha[strcspn(linha,"\n")] = '\0';

            NODO *aux =
                sistema->biblioteca->pInicio;

            while(aux)
            {
                MUSICA *m =
                    aux->pObjeto;

                if(strcmp(
                    m->musica,
                    linha)==0)
                {
                    playlist->insere(
                        playlist,
                        m);

                    break;
                }

                aux = aux->pProximo;
            }
        }
    }

    fclose(file);
}

////////////////////////////////////////