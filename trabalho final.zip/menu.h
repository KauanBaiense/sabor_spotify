#ifndef MENU_H
#define MENU_H

#include "sistema.h"

void MenuPrincipal(SISTEMA *sistema);
void MenuPesquisa(SISTEMA *sistema);
void MenuPlaylist(SISTEMA *sistema);

void RemoverMusicaBiblioteca(SISTEMA *sistema);
void RemoverMusicaPlaylist(SISTEMA *sistema);

void RemoverPlaylist(SISTEMA *sistema);

#endif