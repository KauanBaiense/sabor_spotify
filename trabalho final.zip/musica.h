typedef struct
{
    char musica[100];
    char genero[50];
    char artista[50];
    char link[100];
    float minutos;
} MUSICA;