#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "menu.h"
#include "playlist.h"
#include "musica.h"

////////////////////////////

void tolow(char *str)
{
    for (int i = 0 ; str[i]; i++)
        str[i] = tolower((unsigned char)str[i]);
}

//////////////////////////

void ImprimeMusica(void *obj)
{
    if(obj == NULL)
        return;

    MUSICA *m = (MUSICA *)obj;

    printf("---------------------------------\n");
    printf("Musica  : %s\n", m->musica);
    printf("Genero  : %s\n", m->genero);
    printf("Artista : %s\n", m->artista);
    printf("Duracao : %.2f min\n", m->minutos);
    printf("Link    : %s\n", m->link);
}

/////////////////////////

void CadastrarMusica(SISTEMA *sistema)
{
    MUSICA *m = malloc(sizeof(MUSICA));

    getchar();

    printf("Nome: ");
    fgets(m->musica,100,stdin);
    m->musica[strcspn(m->musica,"\n")] = '\0';

    printf("Genero: ");
    fgets(m->genero,50,stdin);
    m->genero[strcspn(m->genero,"\n")] = '\0';

    printf("Artista: ");
    fgets(m->artista,50,stdin);
    m->artista[strcspn(m->artista,"\n")] = '\0';

    printf("Link: ");
    fgets(m->link,100,stdin);
    m->link[strcspn(m->link,"\n")] = '\0';

    printf("Minutos: ");
    scanf("%f",&m->minutos);

    tolow(m->artista);
    tolow(m->genero);
    tolow(m->musica);

    sistema->biblioteca->insere(
        sistema->biblioteca,
        m
    );

    printf("Musica cadastrada!\n");
}

//////////////////////////////////////

void ImprimirBiblioteca(SISTEMA *sistema)
{
    if(sistema == NULL ||
       sistema->biblioteca == NULL ||
       sistema->biblioteca->pInicio == NULL)
    {
        printf("Biblioteca vazia!\n");
        return;
    }

    printf("\n===== BIBLIOTECA =====\n");

    sistema->biblioteca->paracada(
        sistema->biblioteca,
        ImprimeMusica
    );

    printf("----------------------\n");
}
//////////////////////////////////////

void PesquisarMusica(SISTEMA *sistema)
{
    char nome[100];

    getchar();

    printf("Nome da musica: ");

    fgets(nome,sizeof(nome),stdin);

    tolow(nome);

    nome[strcspn(nome,"\n")] = '\0';

    NODO *aux =
        sistema->biblioteca->pInicio;

    while(aux)
    {
        MUSICA *m =
            (MUSICA*) aux->pObjeto;

        if(strcmp(m->musica,nome) == 0)
        {
            ImprimeMusica(m);
            return;
        }

        aux = aux->pProximo;
    }

    printf("Nao encontrada.\n");
}

//////////////////////////////////////

void ListarArtistas(SISTEMA *sistema)
{
    char artistas[100][50];

    int total = 0;

    NODO *aux =
        sistema->biblioteca->pInicio;

    while(aux)
    {
        MUSICA *m =
            aux->pObjeto;

        int existe = 0;

        for(int i=0;i<total;i++)
        {
            if(strcmp(
                artistas[i],
                m->artista)==0)
            {
                existe = 1;
                break;
            }
        }

        if(!existe)
        {
            strcpy(
                artistas[total],
                m->artista);

            total++;
        }

        aux = aux->pProximo;
    }

    printf("\nArtistas cadastrados:\n");

    for(int i=0;i<total;i++)
        printf("%s\n", artistas[i]);
}

//////////////////////////////////////

void PesquisarArtista(SISTEMA *sistema)
{
    char artista[50];

    ListarArtistas(sistema);

    getchar();

    printf("\nArtista: ");

    fgets(
        artista,
        sizeof(artista),
        stdin);

    tolow(artista);

    artista[strcspn(
        artista,
        "\n")] = '\0';

    NODO *aux =
        sistema->biblioteca->pInicio;

    while(aux)
    {
        MUSICA *m =
            aux->pObjeto;

        if(strcmp(
            artista,
            m->artista)==0)
        {
            ImprimeMusica(m);
        }

        aux = aux->pProximo;
    }
}

/////////////////////////////////////

void ListarGeneros(SISTEMA *sistema)
{
    char generos[100][50];

    int total = 0;

    NODO *aux =
        sistema->biblioteca->pInicio;

    while(aux)
    {
        MUSICA *m =
            aux->pObjeto;

        int existe = 0;

        for(int i=0;i<total;i++)
        {
            if(strcmp(
                generos[i],
                m->genero)==0)
            {
                existe = 1;
                break;
            }
        }

        if(!existe)
        {
            strcpy(
                generos[total],
                m->genero);

            total++;
        }

        aux = aux->pProximo;
    }

    printf("\nGeneros cadastrados:\n");

    for(int i=0;i<total;i++)
        printf("%s\n",generos[i]);
}

/////////////////////////////////////

void PesquisarGenero(SISTEMA *sistema)
{
    char genero[50];

    ListarGeneros(sistema);

    getchar();

    printf("\nGenero: ");

    fgets(
        genero,
        sizeof(genero),
        stdin);

    tolow(genero);

    genero[strcspn(
        genero,
        "\n")] = '\0';

    NODO *aux =
        sistema->biblioteca->pInicio;

    while(aux)
    {
        MUSICA *m =
            aux->pObjeto;

        if(strcmp(
            genero,
            m->genero)==0)
        {
            ImprimeMusica(m);
        }

        aux = aux->pProximo;
    }
}

/////////////////////////////////////



/////////////////////////////////////

void MenuPesquisa(SISTEMA *sistema)
{
    int opc;

    do
    {
        printf("\n");
        printf("===== PESQUISA =====\n");

        printf("1 - Pesquisar musica\n");
        printf("2 - Pesquisar artista\n");
        printf("3 - Pesquisar genero\n");
        printf("4 - Voltar\n");
        printf("= Escolha uma Opção =\n");
        scanf("%d",&opc);

        switch(opc)
        {
            case 1:
                system("clear");
                PesquisarMusica(sistema);
                break;

            case 2:
                system("clear");
                PesquisarArtista(sistema);
                break;

            case 3:
                system("clear");
                PesquisarGenero(sistema);
                break;
            default:
                system ("clear");
                if (opc > 4)
                {
                    printf("=== Opção Invalida ===\n");
                }
            }

    }while(opc != 4);
}

///////////////////////////////////

void CriarPlaylistSistema(SISTEMA *sistema)
{
    char nome[50];

    getchar();

    printf("Nome da playlist: ");

    fgets(nome,sizeof(nome),stdin);

    tolow(nome);

    nome[strcspn(nome,"\n")] = '\0';

    PLAYLIST *playlist =
        CriarPlaylist(nome);

    sistema->playlists->insere(
        sistema->playlists,
        playlist
    );

    printf("Playlist criada!\n");
}

////////////////////////////////////

void ListarPlaylists(SISTEMA *sistema)
{
    NODO *aux =
        sistema->playlists->pInicio;

    int i = 1;

    while(aux)
    {
        PLAYLIST *playlist =
            aux->pObjeto;

        printf("%d - %s\n",
                i,
                playlist->nome);

        aux = aux->pProximo;
        i++;
    }
}

///////////////////////////////////

PLAYLIST *EscolherPlaylist(
            SISTEMA *sistema)
{
    ListarPlaylists(sistema);

    int escolha;

    printf("Escolha: ");
    scanf("%d",&escolha);

    NODO *aux =
        sistema->playlists->pInicio;

    int i = 1;

    while(aux)
    {
        if(i == escolha)
            return aux->pObjeto;

        aux = aux->pProximo;
        i++;
    }

    return NULL;
}

////////////////////////////////

void AdicionarMusicaPlaylist(
            SISTEMA *sistema)
{
    PLAYLIST *playlist =
        EscolherPlaylist(sistema);

    if(!playlist)
        return;

    char nome[100];

    getchar();

    printf("Nome da musica: ");

    fgets(nome,sizeof(nome),stdin);

    tolow(nome);

    nome[strcspn(nome,"\n")] = '\0';

    NODO *aux =
        sistema->biblioteca->pInicio;

    while(aux)
    {
        MUSICA *m =
            aux->pObjeto;

        if(strcmp(m->musica,nome) == 0)
        {
            playlist->insere(
                playlist,
                m
            );

            printf("Adicionada!\n");
            return;
        }

        aux = aux->pProximo;
    }

    printf("Musica nao encontrada.\n");
}

////////////////////////////////////////////

void VerPlaylist(SISTEMA *sistema)
{
    PLAYLIST *playlist =
        EscolherPlaylist(sistema);

    if(!playlist)
        return;

    printf("\nPlaylist: %s\n",
            playlist->nome);

    playlist->paracada(
        playlist,
        ImprimeMusica
    );
}

//////////////////////////////////////////////////

void MenuPlaylist(SISTEMA *sistema)
{
    int opc;

    do
    {
        printf("\n");
        printf("===== PLAYLISTS =====\n");

        printf("1 - Listar playlists\n");
        printf("2 - Criar playlist\n");
        printf("3 - Adicionar musica\n");
        printf("4 - Ver playlist\n");
        printf("5 - Remover núsica\n");
        printf("6 - Apagar playlist\n");
        printf("7 - Voltar\n");
        printf("= Escolha uma Opção =\n");
        scanf("%d",&opc);

        switch(opc)
        {
            case 1:
                system("clear");
                ListarPlaylists(sistema);
                break;

            case 2:
                system("clear");
                CriarPlaylistSistema(sistema);
                break;

            case 3:
                system("clear");
                AdicionarMusicaPlaylist(
                    sistema);
                break;

            case 4:
                    system("clear");
                VerPlaylist(sistema);
                break;
            case 5 :
                system("clear");
                RemoverMusicaPlaylist(sistema);
                break;
            case 6 :
                RemoverPlaylist(sistema);
                break;
            default:
                system ("clear");
                if (opc > 7 )
                {
                    printf("=== Opção Invalida ===\n");
                }
        }

    } while(opc != 7);
}

///////////////////////////////////////////////

void MenuPrincipal(SISTEMA *sistema)
{
    int opc;

    do
    {
        printf("\n");
        printf("===== SABOR SPOTIFY =====\n");

        printf("1 - Cadastrar musica\n");
        printf("2 - Listar biblioteca\n");
        printf("3 - Pesquisar\n");
        printf("4 - Playlists\n");
        printf("5- Remover música\n");
        printf("6 - Sair\n");

        printf("=== Escolha uma Opção ====\n");
        scanf("%d",&opc);

        switch(opc)
        {
            case 1:
                system("clear");
                CadastrarMusica(sistema);
                break;

            case 2:
                system("clear");
                ImprimirBiblioteca(sistema);
                break;

            case 3:
                system("clear");
                MenuPesquisa(sistema);
                break;

            case 4:
                system("clear");
                MenuPlaylist(sistema);
                break;
            case 5 :
                system("clear");
                RemoverMusicaBiblioteca(sistema);
                break;
            default:
                system ("clear");
                if (opc >6 ){
                    printf("=== Opção Invalida ===\n");
                }
        }

    } while(opc != 6);
}

/////////////////////////////////////////////

MUSICA *BuscarMusica(
        SISTEMA *sistema,
        char *nome)
{
    NODO *aux =
        sistema->biblioteca->pInicio;

    while(aux)
    {
        MUSICA *m =
            aux->pObjeto;

        if(strcmp(
            m->musica,
            nome) == 0)
        {
            return m;
        }

        aux =
            aux->pProximo;
    }

    return NULL;
}

/////////////////////////////////////////////

void RemoverMusicaDeTodasPlaylists(
        SISTEMA *sistema,
        MUSICA *musica)
{
    NODO *auxPlaylist =
        sistema->playlists->pInicio;

    while(auxPlaylist)
    {
        PLAYLIST *playlist =
            auxPlaylist->pObjeto;

        playlist->removeObjeto(
            playlist,
            musica);

        auxPlaylist =
            auxPlaylist->pProximo;
    }
}

////////////////////////////////////////////

void RemoverMusicaBiblioteca(
        SISTEMA *sistema)
{
    char nome[100];

    getchar();

    printf("Nome da musica: ");

    fgets(nome,
          sizeof(nome),
          stdin);

    nome[strcspn(
        nome,
        "\n")] = '\0';

    MUSICA *m =
        BuscarMusica(
            sistema,
            nome);

    if(m == NULL)
    {
        printf(
            "Musica nao encontrada.\n");

        return;
    }

    RemoverMusicaDeTodasPlaylists(
        sistema,
        m);

    sistema->biblioteca->removeObjeto(
        sistema->biblioteca,
        m);

    free(m);

    printf(
        "Musica removida.\n");
}

/////////////////////////////////////////////

void RemoverMusicaPlaylist(
        SISTEMA *sistema)
{
    PLAYLIST *playlist =
        EscolherPlaylist(
            sistema);

    if(!playlist)
        return;

    char nome[100];

    getchar();

    printf(
        "Nome da musica: ");

    fgets(nome,
          sizeof(nome),
          stdin);

    nome[strcspn(
        nome,
        "\n")] = '\0';

    NODO *aux =
        playlist->pInicio;

    while(aux)
    {
        MUSICA *m =
            aux->pObjeto;

        if(strcmp(
                m->musica,
                nome) == 0)
        {
            playlist->removeObjeto(
                playlist,
                m);

            printf(
                "Musica removida da playlist.\n");

            return;
        }

        aux =
            aux->pProximo;
    }

    printf(
        "Musica nao encontrada.\n");
}

/////////////////////////////////////////////

PLAYLIST *EscolherPlaylistPorIndice(
        SISTEMA *sistema,
        int indice)
{
    NODO *aux =
        sistema->playlists->pInicio;

    int i = 1;

    while(aux)
    {
        if(i == indice)
            return aux->pObjeto;

        aux = aux->pProximo;
        i++;
    }

    return NULL;
}

////////////////////////////////////////////////

void RemoverPlaylist(
        SISTEMA *sistema)
{
    if(sistema->playlists->pInicio == NULL)
    {
        printf("Nao existem playlists.\n");
        return;
    }

    ListarPlaylists(sistema);

    int escolha;

    printf("\nPlaylist para remover: ");
    scanf("%d", &escolha);

    PLAYLIST *playlist =
        EscolherPlaylistPorIndice(
            sistema,
            escolha);

    if(playlist == NULL)
    {
        printf("Playlist invalida.\n");
        return;
    }

    sistema->playlists->removeObjeto(
        sistema->playlists,
        playlist);

    playlist->destroi(playlist);

    printf("Playlist removida.\n");
}

//////////////////////////////////////////////

